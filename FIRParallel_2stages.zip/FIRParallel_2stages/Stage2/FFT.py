#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 11 13:04:57 2023

@author: samuel
"""

import matplotlib.pyplot as plt
import numpy as np
from scipy.fftpack import fft, ifft
from bitstring import Bits
from scipy.stats import pearsonr

plt.style.use('seaborn-poster')

# sampling rate
sr = 2000
# sampling interval
ts = 1.0/sr
t = np.arange(0,1,ts)

freq = 1.
x = 3*np.sin(2*np.pi*freq*t)

freq = 4
x += np.sin(2*np.pi*freq*t)

freq = 7   
x += 0.5* np.sin(2*np.pi*freq*t)

plt.figure(figsize = (8, 6))
plt.plot(t, x, 'r')
plt.ylabel('Amplitude')

plt.show()


X = fft(x)/len(x)
N = len(X)
n = np.arange(N)
T = N/sr
freq = n/T 

plt.figure(figsize = (12, 6))
plt.subplot(121)

plt.stem(freq, 2*np.abs(X), 'b', markerfmt=" ", basefmt="-b")
plt.xlabel('Freq (Hz)')
plt.ylabel('FFT Amplitude |X(freq)|')
plt.xlim(0, 10)

plt.subplot(122)
plt.plot(t, ifft(X), 'r')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.tight_layout()
plt.show()

#####################

# Getting the contents of the input data
with open('signal_5snr_64_sine.data', 'r') as ifile:
    input_signal = ifile.read()
    
# Split the string input into lines (as list)
input_list = input_signal.splitlines()

input_array = []

# 16 is our wordlength from testbench
for line in input_list:
    # Get the LSB 16 bits  
    a = Bits(bin=line,length=16)
    input_array.append(a.int)
    
res = []
for val in input_array:
    res.append(val/max(input_array))
    

sr = 63
X = fft(res)
N = len(res)
n = np.arange(N)
T = N/sr
freq = n/T

# sampling interval
ts = 1.0/sr
t = np.arange(0,1+ts,ts)


plt.figure(figsize = (12, 6))
plt.subplot(121)



plt.stem(freq[0:int(len(freq)/2)], (2*np.pi*np.abs(X)/N)[0:int(len(freq)/2)], 'b', markerfmt=" ", basefmt="-b")
plt.xlabel('Freq (Hz)')
plt.ylabel('FFT Amplitude |X(freq)|')
#plt.xlim(0, 10)



plt.subplot(122)
plt.plot(t, ifft(fft(res)), 'r')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.tight_layout()
plt.show()

output = (2*np.pi*np.abs(X)/N)[0:int(len(freq)/2)]

#####

# Target 64 samples
target = [0,1631,3246,4829,6364,7836,9229,10531,11729,12810,13763,14580,15251,15772,16135,16338,16379,16257,15973,15531,14934,14189,13303,12284,11144,9893,8543,7109,5604,4043,2442,817,-817,-2442,-4043,-5604,-7109,-8543,-9893,-11144,-12284,-13303,-14189,-14934,-15531,-15973,-16257,-16379,-16338,-16135,-15772,-15251,-14580,-13763,-12810,-11729,-10531,-9229,-7836,-6364,-4829,-3246,-1631,-0]

res = []
for val in target:
    res.append(val/max(target))
    

sr = 63
X = fft(res)
N = len(res)
n = np.arange(N)
T = N/sr
freq = n/T

# sampling interval
ts = 1.0/sr
t = np.arange(0,1+ts,ts)


plt.figure(figsize = (12, 6))
plt.subplot(121)



plt.stem(freq[0:int(len(freq)/2)], (2*np.pi*np.abs(X)/N)[0:int(len(freq)/2)], 'b', markerfmt=" ", basefmt="-b")
plt.xlabel('Freq (Hz)')
plt.ylabel('FFT Amplitude |X(freq)|')
#plt.xlim(0, 10)



plt.subplot(122)
plt.plot(t, ifft(fft(res)), 'r')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.tight_layout()
plt.show()

desired = (2*np.pi*np.abs(X)/N)[0:int(len(freq)/2)]

fitness, p_value = pearsonr(output, desired)


#####

# Target 128 samples
target = [0,1612,3208,4772,6291,7748,9131,10425,11617,12697,13654,14479,15163,15700,16085,16313,16384,16295,16049,15647,15093,14393,13553,12582,11488,10284,8979,7587,6122,4598,3029,1430,-182,-1793,-3386,-4946,-6459,-7908,-9282,-10565,-11745,-12812,-13754,-14563,-15231,-15751,-16118,-16329,-16382,-16275,-16011,-15592,-15021,-14305,-13450,-12464,-11358,-10141,-8826,-7426,-5953,-4423,-2850,-1249,364,1974,3564,5120,6626,8067,9431,10703,11871,12924,13852,14646,15297,15800,16150,16343,16378,16253,15972,15535,14947,14215,13345,12345,11226,9997,8672,7263,5783,4247,2670,1067,-546,-2154,-3741,-5292,-6792,-8225,-9579,-10840,-11996,-13036,-13949,-14726,-15361,-15847,-16180,-16355,-16372,-16230,-15930,-15476,-14872,-14124,-13238,-12225,-11092,-9853,-8517,-7099,-5612,-4071,-2490,-885]
  
res = []
for val in target:
    res.append(val/max(target))
    

sr = 128
X = fft(res)
N = len(res)
n = np.arange(N)
T = N/sr
freq = n/T

# sampling interval
ts = 1.0/sr
t = np.arange(0,1,ts)


plt.figure(figsize = (12, 6))
plt.subplot(121)



plt.stem(freq[0:int(len(freq)/2)], (2*np.pi*np.abs(X)/N)[0:int(len(freq)/2)], 'b', markerfmt=" ", basefmt="-b")
plt.xlabel('Freq (Hz)')
plt.ylabel('FFT Amplitude |X(freq)|')
#plt.xlim(0, 10)



plt.subplot(122)
plt.plot(t, ifft(fft(res)), 'r')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.tight_layout()
plt.show()

desired = (2*np.pi*np.abs(X)/N)[0:int(len(freq)/2)]

fitness, p_value = pearsonr(output, desired)